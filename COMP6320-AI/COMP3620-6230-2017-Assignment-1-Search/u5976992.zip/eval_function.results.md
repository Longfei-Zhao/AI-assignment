# My result
*(argument: 1, 0.3, 0.25)*

Maze | Depth | Score
-----|-------|-----
testAdversarial | 12 | 257.89
smallAdversarial | 2 | 92.18
aiAdversarial | 10 | 86.87
anuAdversarial | 8 | -106.36
mazeAdversarial | 10 | -243.92
smallDenseAdversarial | 6 | 344.13
aiDenseAdversarial | 6 | -764.50
anuDenseAdversarial | 6 | -366.81
mazeDenseAdversarial | 6 | 819.40
