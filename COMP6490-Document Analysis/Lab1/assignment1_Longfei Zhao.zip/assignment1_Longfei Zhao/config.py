ES_HOSTS = ['http://localhost:9200']
SETTINGS_PATH = './es_settings_english.json'
DOC_TYPE = 'doc'
DOCS_PATH = '../gov-test-collection/documents/'
INDEX_NAME = 'longfei'
PRINT_EVERY = 1
QUERY_TOPICS_PATH = '../gov-test-collection/topics/gov.topics'
MY_NAME = 'longfei'
